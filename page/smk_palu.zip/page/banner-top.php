<div class="banner-top">
    <div class="bg-banner py-3">
        <div class="container">
            <?php
            include "page/navbar.php"
            ?>

            <div class="text-banner text-center ">
                <h5 class="text-warning fw-normal">Membangun Masa Depan Bersama di</h5>
                <h1 class="text-white">SMK Pangudi Luhur Seputih Mataram</h1>
                <p class="text-light mb-4">
                    Menjadi Generasi Unggul dan Berwawasan Global

                </p>
                <a href="daftar.php" class="btn btn-warning px-4 text-light r-30 p-2">Pendaftaran Peserta Didik Baru</a>
            </div>
        </div>
    </div>
</div>
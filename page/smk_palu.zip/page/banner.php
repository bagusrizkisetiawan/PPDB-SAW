<div class="banner">
    <div class="bg-banner py-3">
        <div class="container">
            <?php
            include "page/navbar.php"
            ?>

            <div class="text-banner py-5">
                <h2 class="text-light my-5 py-5 text-center"><?php echo $titleBanner; ?></h2>
            </div>
        </div>
    </div>
</div>
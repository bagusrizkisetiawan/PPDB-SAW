<?php

$conn = mysqli_connect("localhost", "root", "", "smk_palu");

$page = @$_GET['page'];
